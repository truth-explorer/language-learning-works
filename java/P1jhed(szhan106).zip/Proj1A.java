/**name initial display, Shuchen Zhang, szhan106, 09/16/2018.
*/
public class Proj1A {
   /** Main method. 
       @param args command line arguments, ignored
    */                              
   public static void main(String[] args) {
      System.out.println("   SSSSSSSS       ZZZZZZZZZ         ");
      System.out.println(" SSS                    ZZ");
      System.out.println("SS                     ZZ");
      System.out.println(" SSS                  ZZ");
      System.out.println("   SSSSS             ZZ");
      System.out.println("       SSS          ZZ");  
      System.out.println("        SSS        ZZ");
      System.out.println("      SSS         ZZ");
      System.out.println(" SSSSSSS         ZZZZZZZZZZ");
   }
}      
      
