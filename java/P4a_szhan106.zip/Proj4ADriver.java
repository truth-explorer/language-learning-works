/** Project 4 A driver.
 *  To be used as a guide on how to set up the workout class.
 */
public class Proj4ADriver {
   
   /** Main test driver program for Project 4, part A.
    *  @param args not used
    */
   public static void main(String[] args) {
   
      Workout bike = new Workout(30, "cardio");
      Workout yoga = new Workout("strength");
      Workout elliptical = new Workout();
      
      System.out.println("Calories for the bike workout are: " + bike.getCalories());
      System.out.println("Duration for the elliptical workout is: " + elliptical.getDuration());
      System.out.println("Calories for the elliptical workout at this duration are: " + elliptical.getCalories());
      elliptical.setDuration(bike.getDuration());
      System.out.print("New elliptical duration is: " + elliptical.getDuration());
      System.out.println(" and calories burnt are " + elliptical.getCalories());
      System.out.println("Is Yoga a cardio workout? " + yoga.isCardio());
      System.out.println("Elliptical workout type? " + elliptical.getType());
      System.out.println("bike workout information is " + bike);
      System.out.println("Calories for the yoga workout are: " + yoga.getCalories());
      
      Workout.setDefaultTime(30);
      Workout walk = new Workout("walk");
      System.out.println("walk type is " + walk.getType());
      System.out.println("original walk info: " + walk);
      walk.setType("cardio");
      System.out.println("updated cardio walk calories: " + walk.getCalories());
      walk.setDuration(45);
      System.out.println("updated 45 walk calories: " + walk.getCalories());
      System.out.println("all updated walk info: " + walk);
      
      // walk.setCalories(1000);  // this should not compile!    
   }
}

/* Expected output if you run this test program:

Calories for the bike workout are: 240
Duration for the elliptical workout is: 60
Calories for the elliptical workout at this duration are: 480
New elliptical duration is: 30 and calories burnt are 240
Is Yoga a cardio workout? false
Elliptical workout type? cardio
bike workout information is 30 240 cardio
Calories for the yoga workout are: 300
walk type is strength
original walk info: 30 150 strength
updated cardio walk calories: 240
updated 45 walk calories: 360
all updated walk info: 45 360 cardio

*/
