/**
  * The class used to create a workout object.
  * @author Shuchen Zhang JHED: szhan106
  */
public class Workout {
   /**
    * The default duration of an exercise.
    */ 
   private static int defaultDuration = 60;
   /**
    * The duration of the workout in minutes.
    */
   private int duration;
   /**
    * The calories burned.
    */
   private int calories;
   /**
    * The type of the workout.
    */
   private String type;
   /**
    * The default constructor.
    * Sets the duration to be the default duration
    * and type to be cardio.
    */
   public Workout() {
      this.duration = Workout.defaultDuration;
      this.type = "cardio";
      this.calories = 8 * this.duration;
   }
   
   /**
    * Sets the duration to be the default duration
    * and type to be the user input. If the input
    * is not valid, the type is set to strength.
    * If type is cardio, calories = 8 * duration
    * If type is strength, calories = 5 * duration
    * @param itype the user input type
    */
   public Workout(String itype) {
      this.duration = Workout.defaultDuration;
      if (itype.equalsIgnoreCase("cardio")) {
         this.type = "cardio";
      }
      else if (itype.equalsIgnoreCase("strength")) {
         this.type = "strength";
      }
      else {
         this.type = "strength";
      }
      this.setCalories();      
   }
   
   /**
    * Sets the duration to be the time
    * and type to be the user input. If the input
    * is not valid, the type is set to strength.
    * If type is cardio, calories = 8 * duration
    * If type is strength, calories = 5 * duration
    * @param itype the user input type
    * @param time the user input duration
    */
   public Workout(int time, String itype) {
      this.duration = time;
      if (itype.equalsIgnoreCase("cardio")) {
         this.type = "cardio";
      }
      else if (itype.equalsIgnoreCase("strength")) {
         this.type = "strength";
      }
      else {
         this.type = "strength";
      }
      this.setCalories();
   }
   
   /**
    * Sets the default duration of an exercise.
    * @param time the user input time
    */
   public static void setDefaultTime(int time) {
      if (time > 60) {
         Workout.defaultDuration = 60;
      }
      else {
         Workout.defaultDuration = time;
      }
   }
   
     
   /**
    * Returns the calories burned.
    * @return calories burned
    */
   public int getCalories() {
      return this.calories;
   }
   
   /**
    * Sets the the duration of the exercise to time.
    * @param time the user input time
    */
   public void setDuration(int time) {
      if (time > 60) {
         this.duration = 60;
      }
      else {
         this.duration = time;
      }
      this.setCalories();
   }

   /**
    * Returns the duration of the exercise.
    * @return the duration
    */
   public int getDuration() {
      return this.duration;
   }
   
   /**
    * Sets the type of the workout.
    * @param stype the type you want to set
    */
   public void setType(String stype) {
      this.type = stype;
      this.setCalories();
   } 
   
   /**
    * Returns whether the workout is a cardio one.
    * @return a boolean value showing whether the workout is a cardio one
    */
   public boolean isCardio() {
      return (this.type.equals("cardio"));
   }
   
   /**
    * Returns the type of the workout.
    * @return the string of the type
    */
   public String getType() {
      return this.type;
   }
    
    /**
     * Calculate the calories burned according to the type
     * and duration of the workout.
     */
   private void setCalories() {
      if (this.type.equals("cardio")) {
         this.calories = 8 * this.duration;
      }
      else {
         this.calories = 5 * this.duration;
      }
   
   } 
   
   /**
    * Overrides the toString Method to print
    * the duration, calories burned, and type
    * of the workout.
    * @return the string representation of the workout
    */
   
   @Override
   public String toString() {
      String s = "" + this.duration + " " + 
         this.calories + " " + this.type;
      return s;
   }
}