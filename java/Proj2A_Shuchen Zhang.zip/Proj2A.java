import java.util.Scanner;
import java.util.Random;

/** DNA Program - Project 2 - Fall 2018.
 *  @author Shuchen Zhang szhan106, 09/29/2018
 */
public class Proj2A {

   /** Convert a character from a DNA sequence to its complement. 
    *  @param ch the character to convert
    *  @return comp the complementary character if ch is one of 
    *  A, T, C, G, 5, or 3 and the original character otherwise.
    */
   public static char complement(char ch) {
      
      char comp = ch;
      
      // TODO: add code here to update comp according to ch
      
      return comp;
   }
   
  /**  Determine whether a DNA sequence is valid or not valid.
    *  @param seq the DNA sequence to validate
    *  @return validity the validity of the DNA sequence
    */
   public static boolean valid(String seq) {
      
      boolean validity = true;
      
      // TODO: add code here to determine if validity stays true
      
      return validity;
   }
   
   /** Generate a random sequence of a given length.
     * @param rand the random number generator to use
     * @param length the length of the strand (# of bases)
     * @return the full sequence including 5'- and -3'
     */
   public static String generate(Random rand, int length) {
      String seq = "";
      
      // TODO: add code here to make seq a valid DNA strand
      // with the requested number of bases (length), 5'- and -3'
      
      return seq;
   }

   /** Compute and return the complement of a valid DNA sequence.
     * @param seq the original DNA sequence
     * @return seqComplement the complement of the original DNA sequence
     */
   public static String complement(String seq) {
      String seqComplement = "";
      
      // TODO: add code here to create the complement
      
      return seqComplement;
   }

   /** Compute and return the reverse of a valid DNA sequence.
     * @param seq the original DNA sequence
     * @return seqReverse the reverse of the original DNA sequence
     */
   public static String reverse(String seq) {
      String seqReverse = "";
      
      // TODO: add code here to create the reverse
      
      return seqReverse;
   }
 
   /** Compare two DNA sequences, character by character, and return number of 
     * character mismatches between the two sequences.
     * @param seq1 the first DNA sequence to compare
     * @param seq2 the second DNA sequence to compare
     * @return the number of character mismatches, 
     *    -1 if they are incompatible lengths
     */
   public static int mutation(String seq1, String seq2) {
      int mutationNum = 0;
      
      // TODO: check lengths and compute mutationNum if compatible
      
      return mutationNum;
   }

   /** Check if a DNA sequence is palindromic, meaning it is the same as its 
     * reverse complement.
     * @param seq the DNA sequence to check
     * @return boolean true if palindromic, false if not palindromic
     */
   public static boolean palindromic(String seq) {
   
      // TODO: update to return true if palindromic, false otherwise
      
      return false;
   }
         
   /** Compute and return restriction enzyme cuts for a sequence.
     * @param seq the original valid DNA sequence
     * @param site a valid recognition site
     * @param where the cut position
     * @return seqCut the new cut DNA sequence
     */
   public static String restrictEnzyme(String seq, String site, int where) {
      String seqCut = "";
      
      // TODO: add code to create the cut sequence
      
      return seqCut;
   }

   /** Main method to provide a menu-driven user interface for doing 
    *  various DNA sequence problems.
    *  @param args not used
    */
   public static void main(String[] args) {
   
      Scanner keyboard = new Scanner(System.in);
      Random randy = new Random();
      
      // initialize seq to starting DNA sequence
      String seq = "5'-ATGCTC-3'";
      
      // Here are some tests to get you started.
      // Make sure that assertions are enabled in jGRASP!
   
      assert complement('A') == 'T' : "complement('A') == 'T' failed";
      assert complement('T') == 'A' : "complement('T') == 'A' failed";
      assert complement('C') == 'G' : "complement('C') == 'G' failed";
      assert complement('G') == 'C' : "complement('G') == 'C' failed";
      assert valid("5'-ACTG-3'") : "valid(\"5'-ACTG-3'\") failed";
      assert valid("5'-actg-3'") : "valid(\"5'-actg-3'\") failed";
      assert valid("5'-ATcG-3'") : "valid(\"5'-ATcG-3'\") failed";
      assert !valid("ATGC") : "not valid (\"ATGC\") failed";
      assert !valid("5'-ATTC") : "not valid (\"5'-ATTC\") failed";
      assert !valid("CCGA-3'") : "not valid (\"CCGA-3'\") failed";
      assert !valid("5'-atic-3'") : "not valid(\"5'-ABCD-3'\") failed";
      assert !valid("3'-ATGC-5'") : "not valid(\"3'-ATGC-5'\") failed";
      assert !valid("5'-ABCD-3'") : "not valid(\"5'-ABCD-3'\") failed";
      assert !valid("5'-ATTG-3") : "not valid (\"5'-ATTG-3\") failed";
      assert !valid("5'AACG-3'") : "not valid (\"5'AACG-3'\") failed";
      
      randy = new Random(1); // need fixed seed for testing
      assert generate(randy, 10).equals("5'-GACCAACGTG-3'") : "generate(randy, 10) failed";
      // you don't have to add more generate tests, this test is just for you
      
      assert complement("5'-ACTG-3'").equals("3'-TGAC-5'") :
         "complement(\"5'-ACTG-3'\").equals(\"3'-TGAC-5'\") failed";
      assert complement("3'-ACTTgA-5'").equals("5'-TGAACT-3'") :
         "complement(\"3'-ACTTgA-5'\").equals(\"5'-TGAACT-3'\")failed";
         
         
      assert reverse("3'-TGAC-5'").equals("5'-CAGT-3'") :
         "reverse(\"3'-TGAC-5'\").equals(\"5'-CAGT-3'\") failed";
      assert reverse("5'-AATTGCc-3'").equals("3'-CCGTTAA-5'") :
         "reverse(\"5'-AATTGCc-3'\").equals(\"3'-CCGTTAA-5'\") failed";
      assert !reverse("3'-TATACCG-5'").equals("'5-CGGTATA-'3") :
         "not reverse(\"3'-TATACCG-5'\").equals(\"'5-CGGTATA-'3\") failed";
          
      assert mutation("5'-ACTG-3'", "5'-ATTC-3'") == 2 :
         "mutation(\"5'-ACTG-3'\", \"5'-ATTC-3'\") == 2 failed";
      assert mutation("5'-ACTAGG-3'", "5'-ACTGTC-3'") == 3 :
         "mutation(\"5'-ACTAGG-3'\", \"5'-ACTGTC-3'\") == 3 failed";
      assert mutation("5'-AAATCG-3'", "5'-aAATCG-3'") == 0 :
         "mutation(\"5'-AAATCG-3'\",\"5'-aAATCG-3'\") == 0 failed";
      assert mutation("5'-ATC-3'", "5'-AA-3'") == -1 :
         "mutation(\"5'-ATC-3'\", \"5'-AA-3'\") == -1 failed";
      assert mutation("5'-AAGC-3'", "5'-ABCT-3'") == -1 :
         "mutation(\"5'-AAGR-3'\", \"5'-ABCT-3'\") == -1 failed";
      assert mutation("5'-AAGCD-3'", "5'-AGCTT") == -1 :
         "mutation(\"5'-AAGCD-3'\", \"5'-AGCTT\") == -1 failed";
   
         
         
      assert palindromic("5'-ATAT-3'") : "palindromic(\"5'-ATAT-3'\") failed";
      assert palindromic("5'-GAATTC-3'") : "palindromic(\"5'-GAATTC-3'\") failed";
      assert palindromic("5'-cccggg-3'") : "palindromic(\"5'-cccggg-3'\") failed";
      assert !palindromic("5'-ATTA-3'") : "not palindromic(\"5'-ATTA-3'\") failed";
      assert !palindromic("5'-ATCCGTA-3'") : "not palindromic(\"5'-ATCCGTA-3'\") failed";
      assert !palindromic("5'-ATTAR-3'") : "not palindromic(\"5'-ATTAR-3'\") failed";
      
      
      assert restrictEnzyme("5'-ATATCCGATAT-3'", "5'-ATAt-3'", 2).equals("5'-AT ATCCGAT AT-3'") :
         "restrictEnzyme(\"5'-ATATCCGATAT-3'\", \"5'-ATAt-3'\", 2).equals(\"5'-AT ATCCGAT AT-3'\") failed";
      assert restrictEnzyme("5'-TTAGAATTCTTAAGTT-3'", "5'-GAATTC-3'", 1).equals("5'-TTAG AATTCTTAAGTT-3'") :
         "restrictEnzyme(\"5'-TTAGAATTCTTAAGTT-3'\", \"5'-GAATTC-3'\", 1).equals(\"5'-TTAG AATTCTTAAGTT-3'\") failed";
      assert restrictEnzyme("5'-ATGCGCTA-3'", "5'-GCCATT-3'", 4).equals("recognition site not valid") :
         "restrictEnzyme(\"5'-ATGCGCTA-3'\", \"5'-GCCATT-3'\", 4).equals(\"recognition site not valid\") failed";
      assert restrictEnzyme("5'-GCGCTA-3'", "5'-GAATTE-3'", 4).equals("recognition site not valid") :
         "restrictEnzyme(\"5'-GCGCTA-3'\", \"5'-GAATTE-3'\", 4).equals(\"recognition site not valid\") failed";
      assert restrictEnzyme("5'-AAATCG-3'", "5'-GCCATT-3",3).equals("recognition site not valid") :
         "restrictEnzyme(\"5'-AAATCG-3'\", \"5'-GCCATT-3\",3).equals(\"recognition site not valid\") failed";
      // Part A - rename class/file Proj2A and write more tests! 
      
      
       
            
   } // end main   

} // end class

