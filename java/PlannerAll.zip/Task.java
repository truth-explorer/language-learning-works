import java.io.IOException;
import java.util.Scanner;

/** Class to represent tasks - todo items.
*/
public class Task {

   /** The actual task to accomplish. */
   private String what;

   /** Default constructor. 
   */
   public Task() {
      this.what = "";
   }

   /** Change the task details.
      @param w what to do
   */
   public void setTask(String w) {
      this.what = w;
   }

   /** Read a task from user input.
      @param in the input source
      @throws IOException if bad or no input
   */
   public void read(Scanner in) throws IOException {
      System.out.println("enter what to do: ");
      this.what = in.nextLine();
   }

   @Override
   public String toString() {
      return this.what;
   }
}
