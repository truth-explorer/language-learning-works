import java.io.IOException;
import java.util.Scanner;

/** This class represents appointment objects that have specific tasks, 
   start times, end times, dates and locations.
*/
public class Appointment extends DueDo {

   /** Where the appointment takes place. */
   private String where;
   /** What time the appointment ends. */
   private Time end;

   @Override
   public void read(Scanner in) throws IOException {
      super.read(in);
      System.out.print("enter end time [hh:mma/p]: ");
      this.end = new Time(in.nextLine());
      System.out.print("enter where: ");
      this.where = in.nextLine();
   }

   @Override
   public String toString() {
      return super.toString() + " - " + this.end + ", " + this.where;
   }
}
