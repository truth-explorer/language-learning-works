import java.io.IOException;
import java.util.Scanner;

/**
This program has menu options to manipulate a personal planner, including:
add a Task, DueDo, or Appointment to the planner (getting input
from the user), as well as search for items, and display all items.

You do not have to make this class checkstyle compliant.
*/

public class PlannerDriver {
    
   private static Scanner keyboard = new Scanner(System.in);

   public static void main(String[] args) throws IOException {
    
      int choice = 1;
      Planner p = new Planner();
      Task t;
      DueDo d;
      Appointment a;
      String s;
   
      while (choice != 0) {    
         choice = menu();
         switch (choice) {
            case 0: 
               break;
            case 1: 
               t = new Task();
               t.read(keyboard);
               if (!p.add(t))
                  System.err.println("Sorry, no more room in planner");
               break;
            case 2: 
               d = new DueDo();
               d.read(keyboard);
               if (!p.add(d))
                  System.err.println("Sorry, no more room in planner");
               break;
            case 3:
               a = new Appointment();
               a.read(keyboard);
               if (!p.add(a))
                  System.err.println("Sorry, no more room in planner");
               break;
            case 4: 
               p.display();
               break;
            case 5: 
               System.out.print("what to search for? ");
               s = keyboard.nextLine();
               System.out.println(p.find(s));
               break;
            case 6: 
               System.out.println("there are " + p.size()
                                 + " items in the planner");
               break;
            default: 
               System.err.println("invalid choice!");
         }
      }
   }

   public static int menu() throws IOException {
      int choice = 0;
      System.out.println("0) quit");
      System.out.println("1) add to-do item");
      System.out.println("2) add due item");
      System.out.println("3) add appointment");
      System.out.println("4) display items");
      System.out.println("5) search");
      System.out.println("6) how many");
      System.out.print("  enter choice -> ");
      choice = keyboard.nextInt();
      keyboard.nextLine();  // clear end of line 
      return choice;
   }

}

