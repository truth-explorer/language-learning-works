/** This class creates objects that are personal planners.
*/
public class Planner {

   /** Default maximum size of planner. */
   private static final int MAXSIZE = 1000;
   
   /** Collection of things that must be done. */
   private Task[] todo;
   /** Number of actual tasks in the planner. */
   private int numtasks;

   /** Create a Planner with starting size 10.
   */
   public Planner() {
      this.todo = new Task[10];
      this.numtasks = 0;
   }

   /** Find out how many things are in the planner.
       @return the number
   */
   public int size() {
      return this.numtasks;
   }

   /** Add an item to the planner, expanding the planner
      if not yet at the maximum size.
      @param t the item to add
      @return true if added, false otherwise
   */
   public boolean add(Task t) {
      if (this.numtasks == this.todo.length 
         && this.numtasks < MAXSIZE) { // make bigger
         int newsize = this.numtasks * 2;
         if (newsize > MAXSIZE) {
            newsize = MAXSIZE;
         }
         Task[] temp = new Task[newsize];
         for (int i = 0; i < this.numtasks; i++) {
            temp[i] = this.todo[i];
         }
         this.todo = temp;
      }
      this.todo[this.numtasks++] = t;
      return true;
   }

   /** Display the items in the planner on the screen.
   */
   public void display() {
      for (int i = 0; i < this.numtasks; i++) {
         System.out.println(this.todo[i]);
      }
   }

   /** Find a particular item in the Planner.
       @param s the item to search for
       @return the first Task including item if found, 
       null otherwise
   */
   public Task find(String s) {
      for (int i = 0; i < this.numtasks; i++) {
         if (this.todo[i].toString().indexOf(s) >= 0) {
            return this.todo[i];
         }
      }
      return null;
   }

   /** Delete an object from the Planner, if there.
       @param t the object to delete
       @return true if removed, false otherwise
   */
   public boolean delete(Task t) {
   // Add this if time, and also a menu operation
   // to test it in the PlannerDriver.java file.
   // You will probably need to override equals in
   // each of the Task and subclasses in order to 
   // find the Task to delete.
      return false;
   }

}
