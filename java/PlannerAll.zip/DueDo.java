import java.util.Scanner;
import java.io.IOException;

/** This class represents objects with specific tasks and deadlines.
*/
public class DueDo extends Task {

   /** What time the task is due. */
   private Time due;
   /** What day the task is due. */
   private String date;

   @Override
   public void read(Scanner in) throws IOException {
      super.read(in);
      System.out.print("enter date: ");
      this.date = in.nextLine();
      System.out.print("enter when [hh:mma/p]: ");
      this.due = new Time(in.nextLine());
   }

   @Override
   public String toString() {
      return super.toString() + ", " + this.date + ", " 
         + this.due;
   }
}
